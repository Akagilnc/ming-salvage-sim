import asyncio
from typing import List, Optional

from agno.knowledge.chunking.fixed import FixedSizeChunking
from agno.knowledge.chunking.strategy import ChunkingStrategy, ChunkingStrategyType
from agno.knowledge.document.base import Document
from agno.knowledge.reader.base import Reader
from agno.knowledge.types import ContentType

try:
    import arxiv  # noqa: F401
except ImportError:
    raise ImportError("The `arxiv` package is not installed. Please install it via `pip install arxiv`.")


class ArxivReader(Reader):
    sort_by: arxiv.SortCriterion = arxiv.SortCriterion.Relevance

    @classmethod
    def get_supported_chunking_strategies(cls) -> List[ChunkingStrategyType]:
        """Get the list of supported chunking strategies for Arxiv readers."""
        return [
            ChunkingStrategyType.CODE_CHUNKER,
            ChunkingStrategyType.FIXED_SIZE_CHUNKER,
            ChunkingStrategyType.AGENTIC_CHUNKER,
            ChunkingStrategyType.DOCUMENT_CHUNKER,
            ChunkingStrategyType.RECURSIVE_CHUNKER,
            ChunkingStrategyType.SEMANTIC_CHUNKER,
        ]

    @classmethod
    def get_supported_content_types(cls) -> List[ContentType]:
        return [ContentType.TOPIC]

    def __init__(
        self,
        chunking_strategy: Optional[ChunkingStrategy] = None,
        sort_by: arxiv.SortCriterion = arxiv.SortCriterion.Relevance,
        **kwargs,
    ) -> None:
        if chunking_strategy is None:
            chunk_size = kwargs.get("chunk_size", 5000)
            chunking_strategy = FixedSizeChunking(chunk_size=chunk_size)
        super().__init__(chunking_strategy=chunking_strategy, **kwargs)

        # ArxivReader-specific attributes
        self.sort_by = sort_by
        self._client: Optional[arxiv.Client] = None

    def get_client(self) -> arxiv.Client:
        """Return a cached arxiv.Client, creating it on first use."""
        if self._client is None:
            self._client = arxiv.Client()
        return self._client

    def read(self, query: str) -> List[Document]:
        """
        Search a query from arXiv database

        This function gets the top_k articles based on a user's query, sorted by relevance from arxiv

        @param query:
        @return: List of documents
        """

        documents = []
        search = arxiv.Search(query=query, max_results=self.max_results, sort_by=self.sort_by)

        for result in self.get_client().results(search):
            links = ", ".join([x.href for x in result.links])

            document = Document(
                name=result.title,
                id=result.title,
                meta_data={"pdf_url": str(result.pdf_url), "article_links": links},
                content=result.summary,
            )
            if self.chunk:
                documents.extend(self.chunk_document(document))
            else:
                documents.append(document)

        return documents

    async def async_read(self, query: str) -> List[Document]:
        """
        Search a query from arXiv database asynchronously

        This function gets the top_k articles based on a user's query, sorted by relevance from arxiv

        @param query: Search query string
        @return: List of documents
        """
        return await asyncio.to_thread(self.read, query)
